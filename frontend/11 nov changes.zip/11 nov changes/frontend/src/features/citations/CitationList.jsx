import React from "react";
import CitationPill from "./CitationPill";

const CitationList = ({ sources, expandedSources, toggleExpandedSources, messageId }) => (
  <div className="citations-container">
    <button
      type="button"
      className="citations-title-btn"
      onClick={() => toggleExpandedSources(messageId)}
    >
      SOURCES {expandedSources[messageId] ? "▲" : "▼"}
    </button>
    {expandedSources[messageId] && (
      <div className="citations-pills">
        {sources.map((source, index) => (
          <CitationPill key={`${source.source_file}-${index}`} source={source} />
        ))}
      </div>
    )}
  </div>
);

export default CitationList;