import React from "react";

const CitationPill = ({ source }) => (
  <div
    className="citation-pill"
    title={`${source.source_file}\n\nScore: ${source.score}\n\n${source.snippet || ""}`}
  >
    {source.source_file}
  </div>
);

export default CitationPill;