import React from "react";
import MessageBubble from "./MessageBubble";

const ChatWindow = ({ messages, bottomRef, expandedSources, setExpandedSources }) => (
  <section className="chat-container">
    {messages.length === 0 ? (
      <div className="empty-state">
        <h2>Start a conversation</h2>
        <p>Ask a question or attach a document to search its contents.</p>
      </div>
    ) : (
      messages.map((message) => (
        <MessageBubble
          key={message.id}
          message={message}
          expandedSources={expandedSources}
          setExpandedSources={setExpandedSources}
        />
      ))
    )}
    <div ref={bottomRef} />
  </section>
);

export default ChatWindow;