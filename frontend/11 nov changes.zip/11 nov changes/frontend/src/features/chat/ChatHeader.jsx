import React from "react";

const ChatHeader = ({ clearChat, setSidebarOpen }) => (
  <header className="header">
    <div className="header-left">
      <button
        type="button"
        className="menu-btn"
        onClick={() => setSidebarOpen((prev) => !prev)}
        aria-label="Open sidebar"
      >
        ☰
      </button>
      <h1>Synapse</h1>
    </div>
    <button type="button" className="clear-chat-btn" onClick={clearChat}>
      Clear Chat
    </button>
  </header>
);

export default ChatHeader;