import React from "react";
import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";
import { Prism as SyntaxHighlighter } from "react-syntax-highlighter";
import { oneDark } from "react-syntax-highlighter/dist/esm/styles/prism";

const MessageBubble = ({ message, expandedSources, setExpandedSources }) => (
  <article className={`chat-bubble ${message.role === "user" ? "user" : "bot"}`}>
    {message.attachments?.length > 0 && (
      <div className="message-attachments">
        {message.attachments.map((attachment) => (
          <span key={attachment.attachmentId} className="message-attachment">
            <span aria-hidden="true">📎</span>
            {attachment.filename}
          </span>
        ))}
      </div>
    )}
    {message.role === "assistant" ? (
      message.content ? (
        <>
          <ReactMarkdown
            remarkPlugins={[remarkGfm]}
            components={{
              code({ inline, className, children, ...props }) {
                const match = /language-(\w+)/.exec(className || "");
                if (!inline && match) {
                  return (
                    <SyntaxHighlighter
                      style={oneDark}
                      language={match[1]}
                      PreTag="div"
                      {...props}
                    >
                      {String(children).replace(/\n$/, "")}
                    </SyntaxHighlighter>
                  );
                }
                return <code className={className} {...props}>{children}</code>;
              },
            }}
          >
            {message.content}
          </ReactMarkdown>
          {message.sources && message.sources.length > 0 && (
            <div className="citations-container">
              <button
                type="button"
                className="citations-title-btn"
                onClick={() =>
                  setExpandedSources((prev) => ({
                    ...prev,
                    [message.id]: !prev[message.id],
                  }))
                }
              >
                SOURCES {expandedSources[message.id] ? "▲" : "▼"}
              </button>
              {expandedSources[message.id] && (
                <div className="citations-pills">
                  {message.sources.map((source, index) => (
                    <div
                      key={`${source.source_file}-${index}`}
                      className="citation-pill"
                      title={`${source.source_file}\n\nScore: ${source.score}\n\n${source.snippet || ""}`}
                    >
                      {source.source_file}
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}
        </>
      ) : (
        <span className="typing-indicator">Thinking...</span>
      )
    ) : (
      <div>{message.content}</div>
    )}
  </article>
);

export default MessageBubble;