import React from "react";
import SessionMenu from "./SessionMenu";

const SessionSidebar = ({
  sessions,
  activeSessionId,
  switchSession,
  openMenuSessionId,
  setOpenMenuSessionId,
  renameSession,
  deleteSession,
  createNewChat,
  sidebarOpen,
  setSidebarOpen,
}) => (
  <aside className={`sidebar ${sidebarOpen ? "open" : ""}`}>
    <button type="button" className="new-chat-btn" onClick={createNewChat}>
      + New Chat
    </button>
    <SessionMenu
      sessions={sessions}
      activeSessionId={activeSessionId}
      switchSession={switchSession}
      openMenuSessionId={openMenuSessionId}
      setOpenMenuSessionId={setOpenMenuSessionId}
      renameSession={renameSession}
      deleteSession={deleteSession}
    />
    {sidebarOpen && (
      <button
        type="button"
        className="overlay"
        aria-label="Close sidebar"
        onClick={() => setSidebarOpen(false)}
      />
    )}
  </aside>
);

export default SessionSidebar;