import { useState, useEffect } from "react";
import { STORAGE_KEY, createEmptySession } from "../../../utils/storage";

export const useSessions = () => {
  const [sessions, setSessions] = useState(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed.sessions) && parsed.sessions.length > 0) {
          return {
            activeSessionId: parsed.activeSessionId,
            sessions: parsed.sessions.map((session) => ({
              ...session,
              messages: session.messages || [],
              attachments: session.attachments || [],
            })),
          };
        }
      }
    } catch (error) {
      console.error("Unable to restore sessions:", error);
    }
    const defaultSession = createEmptySession();
    return {
      activeSessionId: defaultSession.sessionId,
      sessions: [defaultSession],
    };
  });

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(sessions));
  }, [sessions]);

  return { sessions, setSessions };
};
