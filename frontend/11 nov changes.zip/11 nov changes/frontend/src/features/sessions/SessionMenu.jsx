import React from "react";
import SessionItem from "./SessionItem";

const SessionMenu = ({
  sessions,
  activeSessionId,
  switchSession,
  openMenuSessionId,
  setOpenMenuSessionId,
  renameSession,
  deleteSession,
}) => (
  <div className="session-list">
    {sessions.map((session) => (
      <SessionItem
        key={session.sessionId}
        session={session}
        activeSessionId={activeSessionId}
        switchSession={switchSession}
        openMenuSessionId={openMenuSessionId}
        setOpenMenuSessionId={setOpenMenuSessionId}
        renameSession={renameSession}
        deleteSession={deleteSession}
      />
    ))}
  </div>
);

export default SessionMenu;