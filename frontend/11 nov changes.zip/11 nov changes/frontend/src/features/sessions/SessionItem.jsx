import React from "react";

const SessionItem = ({
  session,
  activeSessionId,
  switchSession,
  openMenuSessionId,
  setOpenMenuSessionId,
  renameSession,
  deleteSession,
}) => (
  <div
    className={`session-item ${session.sessionId === activeSessionId ? "active" : ""}`}
  >
    <button
      type="button"
      className="session-title"
      onClick={() => switchSession(session.sessionId)}
    >
      <svg
        className="session-icon"
        width="16"
        height="16"
        viewBox="0 0 24 24"
        fill="none"
        stroke="currentColor"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
      >
        <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z" />
      </svg>
      <span className="session-title-text">{session.title}</span>
    </button>
    <button
      type="button"
      className="session-menu-btn"
      onClick={(event) => {
        event.stopPropagation();
        setOpenMenuSessionId(
          openMenuSessionId === session.sessionId ? null : session.sessionId
        );
      }}
      aria-label="Chat options"
    >
      ⋮
    </button>
    {openMenuSessionId === session.sessionId && (
      <div className="session-dropdown">
        <button type="button" onClick={() => renameSession(session.sessionId)}>
          Rename
        </button>
        <button
          type="button"
          className="delete-option"
          onClick={() => deleteSession(session.sessionId)}
        >
          Delete
        </button>
      </div>
    )}
  </div>
);

export default SessionItem;