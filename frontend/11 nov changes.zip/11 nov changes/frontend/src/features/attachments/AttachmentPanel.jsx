import React from "react";
import AttachmentChip from "./AttachmentChip";

const AttachmentPanel = ({ attachments, removeAttachment }) => (
  <div className="attachment-list">
    {attachments.map((attachment) => (
      <AttachmentChip
        key={attachment.localId}
        attachment={attachment}
        onRemove={removeAttachment}
      />
    ))}
  </div>
);

export default AttachmentPanel;