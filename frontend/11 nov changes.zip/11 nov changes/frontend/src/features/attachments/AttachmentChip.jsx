import React from "react";

const AttachmentChip = ({ attachment, onRemove }) => (
  <div className={`attachment-chip attachment-${attachment.status}`}>
    <span className="attachment-icon" aria-hidden="true">📎</span>
    <div className="attachment-details">
      <span className="attachment-name">{attachment.filename}</span>
      <span className="attachment-status">
        {attachment.status === "uploading" && "Uploading and indexing..."}
        {attachment.status === "ready" && `${formatFileSize(attachment.size)} • Ready`}
        {attachment.status === "failed" && (attachment.error || "Upload failed")}
      </span>
    </div>
    <button
      type="button"
      className="remove-attachment-btn"
      disabled={attachment.status === "uploading"}
      onClick={() => onRemove(attachment)}
      aria-label={`Remove ${attachment.filename}`}
    >
      ×
    </button>
  </div>
);

export default AttachmentChip;