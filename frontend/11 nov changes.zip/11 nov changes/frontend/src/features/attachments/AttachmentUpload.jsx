const AttachmentUpload = ({
  query,
  setQuery,
  handleSearch,
  loading,
  uploading,
  uploadError,
  fileInputRef,
  handleFileSelection,
  openFilePicker,
}) => {
  return (
    <footer className="composer">

      {uploadError && (
        <div
          className="upload-error"
          role="alert"
        >
          {uploadError}
        </div>
      )}

      <div className="input-section">

        <input
          ref={fileInputRef}
          className="attachment-file-input"
          type="file"
          accept=".pdf,.docx,.txt,.csv"
          multiple
          onChange={handleFileSelection}
        />

        <button
          type="button"
          className="attachment-btn"
          onClick={openFilePicker}
          disabled={loading || uploading}
          aria-label="Attach files"
          title="Attach PDF, DOCX, TXT, or CSV"
        >
          {uploading ? (
            <span className="button-spinner" />
          ) : (
            "📎"
          )}
        </button>

        <input
          className="message-input"
          type="text"
          placeholder={
            uploading
              ? "Uploading attachment..."
              : "Send a message..."
          }
          value={query}
          disabled={uploading}
          onChange={(event) =>
            setQuery(event.target.value)
          }
          onKeyDown={(event) => {
            if (
              event.key === "Enter" &&
              !event.shiftKey &&
              query.trim() &&
              !loading &&
              !uploading
            ) {
              event.preventDefault();
              handleSearch();
            }
          }}
        />

        <button
          type="button"
          className="send-btn"
          onClick={handleSearch}
          disabled={
            loading ||
            uploading ||
            !query.trim()
          }
        >
          {loading
            ? "Sending..."
            : "Send"}
        </button>

      </div>
    </footer>
  );
};

export default AttachmentUpload;