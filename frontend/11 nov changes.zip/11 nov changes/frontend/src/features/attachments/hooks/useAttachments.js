import { getFileExtension, formatFileSize } from "../../../utils/helpers";
import { ALLOWED_FILE_EXTENSIONS, MAX_FILE_SIZE_BYTES, MAX_FILE_SIZE_MB } from "../../../utils/constants";

export const validateFile = (file) => {
  const extension = getFileExtension(file.name);
  if (!ALLOWED_FILE_EXTENSIONS.includes(extension)) {
    return `${file.name} is not supported. Choose a PDF, DOCX, TXT, or CSV file.`;
  }
  if (file.size === 0) {
    return `${file.name} is empty.`;
  }
  if (file.size > MAX_FILE_SIZE_BYTES) {
    return `${file.name} exceeds the ${MAX_FILE_SIZE_MB} MB limit.`; // This now works correctly
  }
  return null;
};

export const useAttachments = (sessions, setSessions, setUploading, setUploadError) => {
  
  const handleFileSelection = async (event) => {
    const file = event.target.files?.[0];
    if (!file) return;

    const error = validateFile(file);
    if (error) {
      setUploadError(error);
      return;
    }

    setUploadError("");
    setUploading(true);

    const sessionId = sessions.activeSessionId;
    
    // Create a temporary local attachment reference for the UI state
    const tempId = Date.now().toString();
    const tempAttachment = {
      attachmentId: null,
      id: tempId, // temp identifier
      filename: file.name,
      status: "uploading",
    };

    // Add to current active session's attachments list
    setSessions((prev) => ({
      ...prev,
      sessions: prev.sessions.map((session) =>
        session.sessionId === sessionId
          ? { ...session, attachments: [...(session.attachments || []), tempAttachment] }
          : session
      ),
    }));

    try {
      // Trigger your actual API file upload service
      const response = await uploadAttachment(file, sessionId);
      
      const uploadedId = response.data?.attachmentId || response.data?.id;

      // Update the attachment status from 'uploading' to 'ready'
      setSessions((prev) => ({
        ...prev,
        sessions: prev.sessions.map((session) =>
          session.sessionId === sessionId
            ? {
                ...session,
                attachments: session.attachments.map((att) =>
                  att.id === tempId ? { ...att, attachmentId: uploadedId, status: "ready" } : att
                ),
              }
            : session
        ),
      }));
    } catch (err) {
      const errMsg = err.response?.data?.error || "Failed to upload file.";
      setUploadError(errMsg);
      
      // Remove the failed attachment item from UI state
      setSessions((prev) => ({
        ...prev,
        sessions: prev.sessions.map((session) =>
          session.sessionId === sessionId
            ? { ...session, attachments: session.attachments.filter((att) => att.id !== tempId) }
            : session
        ),
      }));
    } finally {
      setUploading(false);
      if (event.target) event.target.value = ""; // clear input stream
    }
  };

  const removeAttachment = (attachmentIdOrTempId) => {
    const sessionId = sessions.activeSessionId;
    setSessions((prev) => ({
      ...prev,
      sessions: prev.sessions.map((session) =>
        session.sessionId === sessionId
          ? {
              ...session,
              attachments: session.attachments.filter(
                (att) => att.attachmentId !== attachmentIdOrTempId && att.id !== attachmentIdOrTempId
              ),
            }
          : session
      ),
    }));
  };

  return {
    validateFile,
    handleFileSelection,
    removeAttachment,
  };
};
