import { apiClient } from "./apiClient";

export const uploadAttachment = async (formData) => {
  return apiClient.post("/attachments/upload", formData);
};

export const deleteAttachment = async (attachmentId) => {
  return apiClient.delete(`/attachments/${attachmentId}`);
};