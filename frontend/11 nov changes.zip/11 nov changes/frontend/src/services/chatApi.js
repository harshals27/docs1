import { apiClient } from "./apiClient";

export const fetchChatResponse = async (sessionId, messages, attachmentIds) => {
  return apiClient.post("/chat", {
    session_id: sessionId,
    messages: messages.map((message) => ({
      role: message.role,
      content: message.content,
    })),
    attachment_ids: attachmentIds,
  });
};