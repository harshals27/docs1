export const generateId = () =>
  `msg_${Date.now()}_${Math.random().toString(36).slice(2)}`;

export const generateSessionId = () =>
  `session_${Date.now()}_${Math.random().toString(36).slice(2)}`;

export const generateTemporaryAttachmentId = () =>
  `temp_${Date.now()}_${Math.random().toString(36).slice(2)}`;

export const getTimestamp = () => new Date().toISOString();

export const formatChatTitle = (text) => {
  if (!text) return "New Chat";
  const clean = text.replace(/[#*`_~>[\]()]/g, "").replace(/\s+/g, " ").trim();
  if (!clean) return "New Chat";
  const formatted = clean.charAt(0).toUpperCase() + clean.slice(1);
  return formatted.length > 28 ? `${formatted.substring(0, 28).trim()}…` : formatted;
};

export const getFileExtension = (filename) => {
  const dotIndex = filename.lastIndexOf(".");
  if (dotIndex === -1) return "";
  return filename.slice(dotIndex).toLowerCase();
};

export const formatFileSize = (bytes) => {
  if (!bytes) return "0 KB";
  if (bytes < 1024 * 1024) return `${Math.ceil(bytes / 1024)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
};