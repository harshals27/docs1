export const STORAGE_KEY = "chat_sessions";
export const API_BASE_URL = "http://127.0.0.1:8000";
export const ALLOWED_FILE_EXTENSIONS = [".pdf", ".docx", ".txt", ".csv"];
export const MAX_FILE_SIZE_MB = 25;
export const MAX_FILE_SIZE_BYTES = MAX_FILE_SIZE_MB * 1024 * 1024;