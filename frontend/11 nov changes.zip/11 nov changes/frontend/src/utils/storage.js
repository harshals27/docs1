import { generateSessionId } from "./helpers";
export const STORAGE_KEY = "chat_sessions";

export const createEmptySession = () => ({
    sessionId: generateSessionId(),
    title: "New Chat",
    messages: [],
    attachments: [],
  });