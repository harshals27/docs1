import { useEffect, useRef, useState } from "react";
import "./App.css";

import ChatHeader from "./features/chat/ChatHeader";
import ChatWindow from "./features/chat/ChatWindow";
import AttachmentPanel from "./features/attachments/AttachmentPanel";
import AttachmentUpload from "./features/attachments/AttachmentUpload";
import SessionSidebar from "./features/sessions/SessionSidebar";

import { useSessions } from "./features/sessions/hooks/useSessions.js";
import { useAttachments } from "./features/attachments/hooks/useAttachments.js";
import { fetchChatResponse } from "./services/chatApi";
import { uploadAttachment, deleteAttachment } from "./services/attachmentApi";
import { formatChatTitle, getTimestamp, generateId } from "./utils/helpers";
import { createEmptySession } from "./utils/storage";

function App() {
  const [query, setQuery] = useState("");
  const [loading, setLoading] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [uploadError, setUploadError] = useState("");
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [expandedSources, setExpandedSources] = useState({});
  const [openMenuSessionId, setOpenMenuSessionId] = useState(null);

  const bottomRef = useRef(null);
  const fileInputRef = useRef(null);

  const { sessions, setSessions } = useSessions();
  const { validateFile, handleFileSelection, removeAttachment } = useAttachments(
    sessions,
    setSessions,
    setUploading,
    setUploadError
  );

  const openFilePicker = () => {
    if (loading || uploading) {
      return;
    }
  
    fileInputRef.current?.click();
  };

const activeSession =
  sessions.sessions.find((session) => session.sessionId === sessions.activeSessionId) ||
  sessions.sessions[0]; 

  const messages = activeSession?.messages || [];
  const attachments = activeSession?.attachments || [];

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, attachments]);

  const createNewChat = () => {
    const newSession = {
      ...createEmptySession(),
      title: "New Chat",
      messages: [],
      attachments: [],
    };

    setSessions((prev) => ({
      activeSessionId: newSession.sessionId,
      sessions: [newSession, ...prev.sessions],
    }));

    setQuery("");
    setUploadError("");
    setOpenMenuSessionId(null);

    if (window.innerWidth < 768) {
      setSidebarOpen(false);
    }
  };

  const switchSession = (sessionId) => {
    setSessions((prev) => ({
      ...prev,
      activeSessionId: sessionId,
    }));

    setQuery("");
    setUploadError("");
    setOpenMenuSessionId(null);

    if (window.innerWidth < 768) {
      setSidebarOpen(false);
    }
  };

  const renameSession = (sessionId) => {
    const session = sessions.sessions.find((item) => item.sessionId === sessionId);
    const newTitle = window.prompt("Enter new chat title", session?.title || "");

    if (!newTitle?.trim()) return;

    setSessions((prev) => ({
      ...prev,
      sessions: prev.sessions.map((s) =>
        s.sessionId === sessionId ? { ...s, title: newTitle.trim() } : s
      ),
    }));

    setOpenMenuSessionId(null);
  };

  const deleteSession = async (sessionId) => {
    const confirmed = window.confirm("Delete this chat session?");
    if (!confirmed) return;

    const sessionToDelete = sessions.sessions.find((session) => session.sessionId === sessionId);
    const indexedAttachments = (sessionToDelete?.attachments || []).filter(
      (attachment) => attachment.status === "ready" && attachment.attachmentId
    );

    await Promise.allSettled(
      indexedAttachments.map((attachment) => deleteAttachment(attachment.attachmentId))
    );

    setSessions((prev) => {
      const remainingSessions = prev.sessions.filter((session) => session.sessionId !== sessionId);

      if (remainingSessions.length === 0) {
        const newSession = {
          ...createEmptySession(),
          title: "New Chat",
          messages: [],
          attachments: [],
        };

        return {
          activeSessionId: newSession.sessionId,
          sessions: [newSession],
        };
      }

      const nextActiveSessionId =
        prev.activeSessionId === sessionId ? remainingSessions[0].sessionId : prev.activeSessionId;

      return {
        activeSessionId: nextActiveSessionId,
        sessions: remainingSessions,
      };
    });

    setOpenMenuSessionId(null);
  };

  const handleSearch = async () => {
    if (!query.trim() || loading || uploading) return;

    const sessionId = sessions.activeSessionId;
    const currentSession = sessions.sessions.find((session) => session.sessionId === sessionId);

    if (!currentSession) return;

    const hasPendingAttachment = (currentSession.attachments || []).some(
      (attachment) => attachment.status === "uploading"
    );

    if (hasPendingAttachment) {
      setUploadError("Allow the attachment upload to finish before sending the message.");
      return;
    }

    const readyAttachments = (currentSession.attachments || []).filter(
      (attachment) => attachment.status === "ready" && attachment.attachmentId
    );

    const submittedQuery = query.trim();

    const userMessage = {
      id: generateId(),
      role: "user",
      content: submittedQuery,
      timestamp: getTimestamp(),
      attachments: readyAttachments.map((attachment) => ({
        attachmentId: attachment.attachmentId,
        filename: attachment.filename,
      })),
    };

    const assistantMessage = {
      id: generateId(),
      role: "assistant",
      content: "",
      sources: [],
      timestamp: getTimestamp(),
    };

    const requestMessages = [...currentSession.messages, userMessage];

    setLoading(true);
    setUploadError("");
    setQuery("");

    setSessions((prev) => ({
      ...prev,
      sessions: prev.sessions.map((session) =>
        session.sessionId === sessionId
          ? {
              ...session,
              title: session.title === "New Chat" ? formatChatTitle(submittedQuery) : session.title,
              messages: [...requestMessages, assistantMessage],
            }
          : session
      ),
    }));

    try {
      const response = await fetchChatResponse(sessionId, requestMessages, readyAttachments);

      const botReply = response.data?.reply || response.data?.error || "No response from server.";
      const botSources = response.data?.sources || [];

      setSessions((prev) => ({
        ...prev,
        sessions: prev.sessions.map((session) =>
          session.sessionId === sessionId
            ? {
                ...session,
                messages: session.messages.map((message) =>
                  message.id === assistantMessage.id
                    ? { ...message, content: botReply, sources: botSources }
                    : message
                ),
              }
            : session
        ),
      }));
    } catch (error) {
      const errorMessage =
        error.response?.data?.detail || error.response?.data?.error || "Error fetching response.";

      setSessions((prev) => ({
        ...prev,
        sessions: prev.sessions.map((session) =>
          session.sessionId === sessionId
            ? {
                ...session,
                messages: session.messages.map((message) =>
                  message.id === assistantMessage.id
                    ? { ...message, content: errorMessage }
                    : message
                ),
              }
            : session
        ),
      }));
    } finally {
      setLoading(false);
    }
  };

  const clearChat = () => {
    setSessions((prev) => ({
      ...prev,
      sessions: prev.sessions.map((session) =>
        session.sessionId === sessions.activeSessionId
          ? { ...session, messages: [] }
          : session
      ),
    }));

    setQuery("");
  };

  return (
    <div className="app-container">
      <SessionSidebar
        sessions={sessions.sessions}
        activeSessionId={sessions.activeSessionId}
        switchSession={switchSession}
        openMenuSessionId={openMenuSessionId}
        setOpenMenuSessionId={setOpenMenuSessionId}
        renameSession={renameSession}
        deleteSession={deleteSession}
        createNewChat={createNewChat}
        sidebarOpen={sidebarOpen}
        setSidebarOpen={setSidebarOpen}
      />
      <main className="main-content">
        <ChatHeader 
          sidebarOpen={sidebarOpen} 
          setSidebarOpen={setSidebarOpen} 
          clearChat={clearChat} 
        />
        
        <ChatWindow 
          messages={messages} 
          loading={loading} 
          bottomRef={bottomRef}
          expandedSources={expandedSources}
          setExpandedSources={setExpandedSources}
        />
        
        {attachments.length > 0 && (
          <AttachmentPanel 
            attachments={attachments} 
            removeAttachment={removeAttachment} 
          />
        )}
        
        <AttachmentUpload 
          query={query}
          setQuery={setQuery}
          handleSearch={handleSearch}
          loading={loading}
          uploading={uploading}
          uploadError={uploadError}
          setUploadError={setUploadError}
          fileInputRef={fileInputRef}
          validateFile={validateFile}
          handleFileSelection={handleFileSelection}
          openFilePicker={openFilePicker}
          activeSessionId={sessions.activeSessionId}
        />
      </main>
    </div>
  );
}

export default App;
